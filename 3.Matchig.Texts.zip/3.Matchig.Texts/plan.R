################################ PLAN DE ACCI??N - SERGIO CENDALES #######################################
##########################################################################################################
rm(list = ls())
#setwd("C:\Users\Sergio Cendales\Documents\Portafolio - Sergio Vladimir Cendales Castillo\3.Matchig.Texts")
setwd("C:/Users/Sergio Cendales/Documents/Portafolio - Sergio Vladimir Cendales Castillo/3.Matchig.Texts")
library(quanteda)
library(tm)
library(readxl)
library(dplyr)
library(tidyr)
library(data.table)
library(plyr)
library(sampling)
#--------------------------------------------------------------------------------------------------------------------------------------------------------
#DESCARGA LA BASE DE COMISIONES
a<-read_excel("comisions2.xlsx")
#ELIMINA REGISTROS CON NA
a<-a[-c(1,2,237:243),]
#CAMBIA NOMBRES A LA BASE DE COMISIONES
colnames(a)<-c("Numero","SIIF","FechaSolicitud","RP","Nombre","Identificacion","Dependencia","Destino",
               "FechaInicio","FechaFin","NumeroDias","Objeto","ValorViaticos","ValorTerrestre","CDPViaticos",
               "CDPTerrestre","Ruta","Rubro","Vinculacion","Salario","Legalizacion1")
#PONE FORMATO FECGA A LAS VARIABLES TIPO FECHA QUE VIENEN COMO TIPO NUMERO
a$FechaSolicitud<-as.Date(as.numeric(as.character(a$FechaSolicitud)), origin = "1899-12-30")
a$FechaInicio<-as.Date(as.numeric(as.character(a$FechaInicio)), origin = "1899-12-30")
a$FechaFin<-as.Date(as.numeric(as.character(a$FechaFin)), origin = "1899-12-30")
#DESCARGA LA BASE DEL PLAN DE ACCION
b <- read_excel("PlanDeAccion.xlsx")
#CAMBIA LOS NOMBRES DEL PLAN DE ACCION
colnames(b)<-c("PactoPND", "LineaPND", "No.ObjetivoInst", "ObjetivoInst", "PorcentajeObjetivo", "No.Estrategia", "Estrategia", "PorcentajeEstrategia",
               "PesoEstrategia", "Dependencia", "No.Meta", "Meta", "PesoMeta", "FechaInicioMeta", "FechaFinMeta", "No.Actividad", "Actividad", "Responsable",
               "CargoResponsable", "NombreIndicador", "FormulaIndicador", "OrigenIndicador", "TipoIndicador", "Estrategico.Apoyo", "MetaAnual", "UnidadDeMedida",
               "FrecuenciaDeMedicion", "FuenteVerificacion", "ProgramacionT1" , "ProgramacionT2", "ProgramacionT3", "ProgramacionT4", "ProgramacionAnual",
               "ProyectoInversion", "ProyectoFuncionamiento", "OtrosRecursosDeFuncionamiento", "PresupuestoApropiado", "ProcesoAsociado",
               "Dimension", "PoliticasDeGestion", "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre",
               "Noviembre", "Diciembre", "ResultadosAlcanzados", "DificultadesPresentadas", "MedidasCorrectivas", "X", "ValorVigente", "ValorComprometido",
               "ValorObligado","T1X","T1XX","T1XXX","T1XXXX", "T1XXXXX", "T1XXXXXX","T2X","T2XX","T2XXX","T2XXXX", "T2XXXXX", "T2XXXXXX",
               "T3X","T3XX","T3XXX","T3XXXX", "T3XXXXX", "T3XXXXXX","T4X","T4XX","T4XXX","T4XXXX", "T4XXXXX", "T4XXXXXX",
               "Compromiso/Apropiacion", "Obligacion/Apropiacion", "ResultadoAcumulado", "ResultadoEsperado", "ResultadoAcumulado/ResultadoEsperado",
               "AvanceMeta", "AvanceObjetivo", "AvanceGeneral","XX","ResultadoAcumulado2", "ResultadoEsperado2","ResultadoAcumulado2/ResultadoEsperado2",
               "AvanceMeta2", "AvanceObjetivo2", "AvanceGeneral2","XX2")

# UNIR LAS ACTIVIDADES CON LAS SUBACTIVIDADES EN UN SOLO VECTOR
#actividad<-data.frame(pmax(unlist(b$Meta),unlist(b$Actividad),na.rm = T))
# UNIR LOS CODIGOS DE  LAS ACTIVIDADES CON LOS CODIGOS DE LAS SUBACTIVIDADES EN UN SOLO VECTOR
#codigo_actividad<-data.frame(pmax(unlist(b$No.Actividad),unlist(b$No.Meta),na.rm = T))

#UNIR ACTIVIDAD CON CODIGO DE ACTIVIDAD
#codigo_actividad<-cbind(codigo_actividad, actividad)

#Saqu� las comisiones del cuarto trimestre
trim4<-rbind(subset(a, format.Date(FechaInicio, "%m")=="10"),subset(a, format.Date(FechaInicio, "%m")=="11"),
             subset(a, format.Date(FechaInicio, "%m")=="12"))
#--------------------------------------------------------------------------------------------------------------------------------------------------------

#data frame con todos los objetivos de las comisiones
objetivos <- tibble(LlaveObjetivos = 1:length(levels(as.factor(trim4$Objeto))), text = levels(as.factor(trim4$Objeto)))
#vector con avtividades que son relevantes para las comisiones

#es necesario filtrar por actividades que tengan planeadas actividades ( quitar las que en programacion tengan 0), y con interes en comisiones
metaT4<-data.frame(cbind(b$Actividad,b$ProgramacionT4))
metaT4$X2<-as.numeric(as.character(metaT4$X2))
colnames(metaT4)<-c("Actividad", "ProgramacionT4")

act<-data.frame(levels(as.factor(b$Actividad)))
names(act)[1]<-"Actividad"

act2<-merge(act, metaT4, by = "Actividad")

act2<-subset(act2, ProgramacionT4 > 0  & !is.na(ProgramacionT4) )
act<-act2$Actividad
act<-act[-c(1,2,5,10,11,16,19,23,24,27,28,29,30,31,32,33,34,35,36,37,38,39,44,45,46,48,49,55,59,60,61,62,63)]
#dataframe unicamentes actividades
#actividades<-tibble(line = 1:length(levels(as.factor(act))), text = levels(as.factor(act)))
actividades<-tibble(LlaveActividades = 1:length(act), text = as.character(act))
#--------------------------------------------------------------------------------------------------------------------------------------------------------
#MATRIZ DE DOCUMENTOS POR ATRIBUTOS  (mo objetivos, ma actividades)
moo<-dfm(objetivos$text, remove = stopwords("spanish"),remove_punct = T , stem = T)
maa<-dfm(actividades$text, remove = stopwords("spanish"),remove_punct = T, stem = T)

#mo<-convert(moo, to = "data.frame")
#ma<-convert(maa, to = "data.frame")
#MATRIZ DE CORRELACIONES (FILAS OBJETIVOS - COLUMNAS ACTIVIDADES)

tstat14<-data.frame(as.matrix(textstat_simil(moo,maa, method = "correlation", margin = "documents")))

#A CADA OBJETIVO SE LA COMISION SE LE ASIGNA LA ACTIVIDAD CON MAYOR CORRELACION EN LA MATRIZ DE CORRELACIONES 
#tstat14$max_actividad<-colnames(tstat14)[apply(tstat14,1,which.max)]
max_actividad<-colnames(tstat14)[apply(tstat14,1,which.max)]
# A LA MATRIZ DE OBJETIVOS SE LE PEGA EL VECTOR DEL CODIGO DE ACIVIDADES CON MAYOT CORRELACION
objetivos<-cbind(objetivos,max_actividad)
#ES LA MISMA MATRIZ DE OBJETIVOS PERO A LAS ACTIVIDADES SE LES QUITO LA PALABRA "TEXT" Y SE LE PUSO A ESE VECTOR EL NOMRBE "NUMEBR"
objetivos<-extract(objetivos, 3, into = "LlaveActividades", regex = "([0-9]+)")
#PONER ACTIVIDADES Y OBJETIVOS COMO FACTOR 
actividades$LlaveActividades<-as.factor(actividades$LlaveActividades);actividades$text<-as.factor(actividades$text);objetivos$LlaveObjetivos<-as.factor(objetivos$LlaveObjetivos);objetivos$text<-as.factor(objetivos$text);objetivos$LlaveActividades<-as.factor(objetivos$LlaveActividades)
#-------------------------------------------------------------------------------------------------------------------------------------------------------
#SE UNE objetivos Y ACTIVIDADES: POR OBJETIVO (TEXT.Y)SE LE A ASIGNIDADO LA ACTIVIDAD(TEXT.X) A QUE MAS LE PEGA : TODOS LOS OBJETIVOS SE LES ASIGNO UNA ACTIVIDAD
un<-merge(actividades, objetivos, by = "LlaveActividades")
#CAMBIO DE NOMBRES LAS COLUMNDAS RELEVANTES Y CREO UN DATA FRAME CON SOLAMENTE ESAS COLUMNAS
names(un)[4]<-"Objetivo"
names(un)[2]<-"Actividad"
#un2<-un[,c(2,4)]
#data frame con las actividades con su programacion y la unidad de medida
actmeta<-data.frame(cbind(b$Actividad, b$ProgramacionT4, b$UnidadDeMedida));colnames(actmeta)<-c("Actividad", "ProgramacionT4", "UnidadDeMedida")
actmeta$ProgramacionT4<-as.numeric(as.character(actmeta$ProgramacionT4))
#version con solo actividades

un3 <- merge(un, actmeta, by = "Actividad")

#ahora lo quiero saber es cuales de las actividades con indicador numerico se les asignaron mas comisiones de las que se fijaron
#segun la programacion  para el cuarto trimestre

#version filtrado por unidad de medida numerico 
un3_num<-filter(un3, UnidadDeMedida == "N�mero" )
#table con las actividades a las cuales se les asignaron comisiones y cuyo indicador es numerico 
act_comision_numeric<-ddply(un3_num, .(Actividad),nrow)
act_comision_numeric_meta<-merge(act_comision_numeric, actmeta, by = "Actividad" )

names(act_comision_numeric_meta)[2]<-"RealizadasT4"
#act_comision_numeric_meta$ProgramacionT4[is.na(act_comision_numeric_meta$ProgramacionT4)]<-0

mal<-matrix(0, nrow = nrow(act_comision_numeric_meta), ncol = 1)

for (i in which(act_comision_numeric_meta$RealizadasT4>act_comision_numeric_meta$ProgramacionT4)) {
  mal[i] = 1
}

act_comision_numeric_meta<-cbind(act_comision_numeric_meta,mal)
change<-subset(act_comision_numeric_meta, mal == 1)

change2<-merge(change, un3[,c(1,2,3,4)], by = "Actividad")
#ID_unit es diferente a LlaveObjetivos . ID_unit me identifica los ojetivos que estan en actividades con meta numerica que sobrepasan la meta
ID_unit<- 1:nrow(change2)
change2<-cbind(change2, ID_unit)
#changedok<-ddply(change2,.(LlaveActividades),function(x) x[sample(nrow(x),2),])

#con estas 2 lineas selecciono aleatoriamente de change 2 el numero de objetivos maximo que establecido por la meta programada para ese trimestre
changedok<-strata(change2, "LlaveActividades", size = change$ProgramacionT4, method = "srswor")

changedok2<-merge(changedok, change2, by = "ID_unit")

#un3 sin tener en cuenta las que no se seleccionaron al azar

#ok<-filter(un3, LlaveObjetivos == setdiff(un3$LlaveObjetivos,setdiff(change2$LlaveObjetivos,changedok2$LlaveObjetivos )))

faltan<-as.numeric(setdiff(change2$LlaveObjetivos,changedok2$LlaveObjetivos))
un3$LlaveObjetivos<-as.numeric(as.character(un3$LlaveObjetivos))
ok<-setdiff(un3$LlaveObjetivos, faltan)

un3_ok<- un3%>% filter(LlaveObjetivos %in% (ok))
#-----------------------------------------------------------------------------------------------------------------------------------------------


# en esta matriz ya tengo identificado las comisiones que estan ok de acuerdo a la meta , hace falta volver a hacer un matriz de documentos por atributos
# con las comisiones que faltan y las actividades numericas que no tienen comision y las actividades porcentuales

actividades_asignadas<-data.table(table(un3$LlaveActividades))
actividades_sinasignar<-filter(actividades_asignadas, N == 0)
names(actividades_sinasignar)[1]<-"LlaveActividades"
actividades_sinasignar2<-merge(actividades_sinasignar, actividades, by = "LlaveActividades" )
names(actividades_sinasignar2)[3]<-"Actividad"
actividades_sinasignar3<-merge(actividades_sinasignar2, actmeta, by = "Actividad" )

un3_por<-filter(un3, UnidadDeMedida == "Porcentaje")
act_comision_porcentaje<-ddply(un3_num, .(Actividad),nrow)

actividades2<-tibble(LlaveActividades = 1:length(union(act_comision_porcentaje$Actividad,actividades_sinasignar3$Actividad)), text = union(act_comision_porcentaje$Actividad,actividades_sinasignar3$Actividad))

change2_faltan<- change2%>% filter(LlaveObjetivos %in% (faltan))




#MATRIZ DE DOCUMENTOS POR ATRIBUTOS  (mo objetivos, ma actividades)
maa2<-dfm(actividades2$text, remove = stopwords("spanish"),remove_punct = T , stem = T)
moo2<-dfm(as.character(change2_faltan$Objetivo), remove = stopwords("spanish"),remove_punct = T, stem = T)

tstat15<-data.frame(as.matrix(textstat_simil(moo2,maa2, method = "correlation", margin = "documents")))



max_actividad2<-colnames(tstat15)[apply(tstat15,1,which.max)]

objetivos2<-data.table(change2_faltan$Objetivo)
names(objetivos2)[1]<-"text"
objetivos2<-merge(objetivos2, objetivos[,c(1,2)], by = "text")


# A LA MATRIZ DE OBJETIVOS SE LE PEGA EL VECTOR DEL CODIGO DE ACIVIDADES CON MAYOT CORRELACION
objetivos2<-cbind(objetivos2,max_actividad2)
#ES LA MISMA MATRIZ DE OBJETIVOS PERO A LAS ACTIVIDADES SE LES QUITO LA PALABRA "TEXT" Y SE LE PUSO A ESE VECTOR EL NOMRBE "NUMEBR"
objetivos2<-extract(objetivos2, 3, into = "LlaveActividades", regex = "([0-9]+)")
#PONER ACTIVIDADES Y OBJETIVOS COMO FACTOR 

#objetivos2<-merge(objetivos2, actividades2, by = "LlaveActividades")

#names(actividades2)[1]<-"text"
#actividades2<-merge(actividades2, actividades[,c(1,2)], by = "text")
actividades2$text<-as.factor(actividades2$text);objetivos2$LlaveActividades<-as.factor(objetivos2$LlaveActividades);actividades2$LlaveActividades<-as.factor(actividades2$LlaveActividades)

#-------------------------------------------------------------------------------------------------------------------------------------------------------
#SE UNE objetivos Y ACTIVIDADES: POR OBJETIVO (TEXT.Y)SE LE A ASIGNIDADO LA ACTIVIDAD(TEXT.X) A QUE MAS LE PEGA : TODOS LOS OBJETIVOS SE LES ASIGNO UNA ACTIVIDAD

#names(objetivos2)[1]<-"Objetivo"
#names(actividades2)[1]<-"Actividad"

un2<-merge(actividades2, objetivos2, by = "LlaveActividades")


#CAMBIO DE NOMBRES LAS COLUMNDAS RELEVANTES Y CREO UN DATA FRAME CON SOLAMENTE ESAS COLUMNAS
names(un2)[3]<-"Objetivo"
names(un2)[2]<-"Actividad"
un2<-merge(un2,actmeta, by = "Actividad")

un3_ok<-rbind(un2,un3_ok)

#####EN ESTA MATRZ UN3_OK YA ESTAN LOS OBJETIVOS DE LAS COMISIONES CON LA ACTIVIDAD MAS CORRELOCIONADA, TENIENDO EN CUENTA EL CUMPLIMIENTO DE LA META DE CADA ACTIVIDAD.
######------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

